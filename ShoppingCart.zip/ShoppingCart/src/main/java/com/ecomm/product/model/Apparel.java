package com.ecomm.product.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "APPAREL")
@PrimaryKeyJoinColumn(name = "APPAREL_ID")
public class Apparel extends Product {

	@Column(name = "APPAREL_TYPE")
	private String type;
	
	@Column(name = "BRAND")
	private String brand;
	
	@Column(name = "DESIGN")
	private String design;
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getDesign() {
		return design;
	}
	
	public void setDesign(String design) {
		this.design = design;
	}	
	
}
