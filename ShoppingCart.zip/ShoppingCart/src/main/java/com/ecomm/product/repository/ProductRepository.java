package com.ecomm.product.repository;

import org.springframework.stereotype.Repository;

import com.ecomm.product.model.Product;

@Repository
public interface ProductRepository extends ProductBaseRepository<Product> {

}
