package com.ecomm.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecomm.product.model.Apparel;
import com.ecomm.product.model.Book;
import com.ecomm.product.model.Product;
import com.ecomm.product.repository.ApparelRepository;
import com.ecomm.product.repository.BookRepository;
import com.ecomm.product.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository productRepo;
	
	@Autowired
	private ApparelRepository apparelRepo;
	
	@Autowired
	private BookRepository bookRepo;

	@Override
	public Iterable<Product> fetchAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public Iterable<Product> fetchProductsById(Iterable<Integer> ids) {
		return productRepo.findAllById(ids);
	}

	@Override
	public Iterable<Apparel> saveApparels(Iterable<Apparel> apparels) {
		return apparelRepo.saveAll(apparels);
	}
	
	@Override
	public Iterable<Book> saveBooks(Iterable<Book> books) {
		return bookRepo.saveAll(books);
	}

	@Override
	public void deleteProducts(Iterable<Product> products) {
		productRepo.deleteAll(products);		
	}
	
}
