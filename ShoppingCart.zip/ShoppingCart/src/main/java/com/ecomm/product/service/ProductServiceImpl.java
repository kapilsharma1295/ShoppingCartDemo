package com.ecomm.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecomm.product.model.Product;
import com.ecomm.product.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository productRepo;

	@Override
	public Iterable<Product> fetchAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public Iterable<Product> fetchProductsById(Iterable<Integer> ids) {
		return productRepo.findAllById(ids);
	}

	@Override
	public Iterable<Product> saveProducts(Iterable<Product> products) {
		return productRepo.saveAll(products);
	}

	@Override
	public void deleteProducts(Iterable<Product> products) {
		productRepo.deleteAll(products);		
	}
	
}
