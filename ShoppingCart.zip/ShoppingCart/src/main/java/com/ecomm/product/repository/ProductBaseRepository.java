package com.ecomm.product.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.ecomm.product.model.Product;

@NoRepositoryBean
public interface ProductBaseRepository<T extends Product> extends CrudRepository<T, Integer> {

}
