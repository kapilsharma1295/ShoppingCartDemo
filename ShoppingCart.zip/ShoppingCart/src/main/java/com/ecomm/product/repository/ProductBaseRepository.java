package com.ecomm.product.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ecomm.product.model.Product;

@Repository
public interface ProductBaseRepository<T extends Product> extends CrudRepository<T, Integer> {

}
