package com.ecomm.product.repository;

import org.springframework.stereotype.Repository;

import com.ecomm.product.model.Apparel;

@Repository
public interface ApparelRepository extends ProductBaseRepository<Apparel> {

}
