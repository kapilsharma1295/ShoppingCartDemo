package com.ecomm.product.service;

import com.ecomm.product.model.Apparel;
import com.ecomm.product.model.Book;
import com.ecomm.product.model.Product;

public interface IProductService {

	public Iterable<Product> fetchAllProducts();
	
	public Iterable<Product> fetchProductsById(Iterable<Integer> ids);
	
	public Iterable<Apparel> saveApparels(Iterable<Apparel> apparels);
	
	public Iterable<Book> saveBooks(Iterable<Book> books);
	
	public void deleteProducts(Iterable<Product> products);
	
}
