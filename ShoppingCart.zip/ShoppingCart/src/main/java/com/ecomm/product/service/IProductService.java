package com.ecomm.product.service;

import com.ecomm.product.model.Product;

public interface IProductService {

	public Iterable<Product> fetchAllProducts();
	
	public Iterable<Product> fetchProductsById(Iterable<Integer> ids);
	
	public Iterable<Product> saveProducts(Iterable<Product> products);
	
	public void deleteProducts(Iterable<Product> products);
	
}
