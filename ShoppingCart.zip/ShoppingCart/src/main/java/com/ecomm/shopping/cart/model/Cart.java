package com.ecomm.shopping.cart.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.ecomm.user.model.User;

@Entity
@Table(name="SHOPPING_CART")
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CART_ID")
	private int id;
	
	@OneToOne
	@JoinColumn(name = "USER_ID", nullable = false)
	private User user;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "cart")
	private Set<ItemDetails> items;
	
	private double amount = 0.0;

	public Set<ItemDetails> getItems() {
		return items;
	}

	public void setItems(Set<ItemDetails> items) {
		this.items = items;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount() {
		for(ItemDetails item : this.items) {
			this.amount += item.getProduct().getPrice() * item.getQuantity();
		}
	}
	
}
