package com.ecomm.shopping.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecomm.shopping.cart.service.IShoppingCartService;

@RestController
@RequestMapping("/api/shoppingcart")
public class ShoppingCartController {

	@Autowired
	private IShoppingCartService cartService;
	
	// API to manage cart CRUD operations
}
