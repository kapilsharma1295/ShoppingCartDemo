package com.ecomm.shopping.cart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecomm.shopping.cart.repository.ShoppingCartRepository;

@Service
@Transactional
public class ShoppingCartServiceImpl implements IShoppingCartService {

	@Autowired
	private ShoppingCartRepository cartRepo;
}
