package com.ecomm.shopping.cart.service;

public interface IShoppingCartService {

}
