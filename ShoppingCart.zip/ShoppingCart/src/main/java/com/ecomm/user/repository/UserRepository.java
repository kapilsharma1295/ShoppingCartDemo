package com.ecomm.user.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ecomm.user.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

}
