package com.ecomm.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecomm.user.model.User;
import com.ecomm.user.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository userRepo;

	@Override
	public Iterable<User> fetchAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public Iterable<User> fetchUsersById(Iterable<Integer> ids) {
		return userRepo.findAllById(ids);
	}

	@Override
	public Iterable<User> saveUsers(Iterable<User> users) {
		return userRepo.saveAll(users);
	}

	@Override
	public void deleteUsers(Iterable<User> users) {
		userRepo.deleteAll(users);
	}
	
}
