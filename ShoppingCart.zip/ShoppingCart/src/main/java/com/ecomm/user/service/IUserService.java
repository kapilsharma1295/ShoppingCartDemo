package com.ecomm.user.service;

import com.ecomm.user.model.User;

public interface IUserService {

	public Iterable<User> fetchAllUsers();
	
	public Iterable<User> fetchUsersById(Iterable<Integer> ids);
	
	public Iterable<User> saveUsers(Iterable<User> users);
	
	public void deleteUsers(Iterable<User> users);
	
}
