package com.ecomm.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecomm.user.model.User;
import com.ecomm.user.service.IUserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	private IUserService userService;
	
	@GetMapping("/all")
	public Iterable<User> fetchAllUsers() {
		return userService.fetchAllUsers();
	}

	@GetMapping
	public Iterable<User> fetchUsersById(Iterable<Integer> ids) {
		return userService.fetchUsersById(ids);
	}

	@PostMapping
	public Iterable<User> saveUsers(Iterable<User> users) {
		return userService.saveUsers(users);
	}

	@DeleteMapping
	public void deleteUsers(Iterable<User> users) {
		userService.deleteUsers(users);
	}
	
}
